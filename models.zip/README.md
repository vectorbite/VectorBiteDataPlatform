VectorBiTE Eco-Informatics Web Application Development Platform
================

Welcome to VectorBiTE’s Web Application Development Platform on Git hub.
Here you can access instructions on using our web app, as well as
getting and submitting data to our databases. You can also get access to
the software development code for our web app.

We are currently finalising work on our first data base, known as the
**Vec**tor Population **Dyn**amics Database (VecDyn). You can all the
necessary information on its usage from [the Vecdyn documentation
pages](https://github.com/vectorbite/VectorBiteDataPlatform/blob/master/static/Documentation/VecDyn/VecDynUserDocs.md).
